@extends('component.layout')
@section('isi')
    @livewire('penggunaComponent')    
@endsection