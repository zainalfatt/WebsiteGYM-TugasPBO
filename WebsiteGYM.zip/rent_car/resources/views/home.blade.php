@extends('layout.tampilan')
@section('title','home - GYM')

@section('content')

@endsection