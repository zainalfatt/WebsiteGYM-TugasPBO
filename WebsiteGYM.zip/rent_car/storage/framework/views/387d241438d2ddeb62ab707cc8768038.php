<?php $__env->startSection('isi'); ?>
    <div class="container-fluid pt-4 px-4">
        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="text-primary">Dashboard Gym</h2>
        </div>

        <!-- Statistik -->
        <div class="row g-4">
            <!-- Total Anggota -->
            <div class="col-sm-6 col-xl-4">
                <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                    <i class="fas fa-users fa-3x text-primary"></i>
                    <div class="ms-3">
                        <p class="mb-2">Total Anggota</p>
                        <h6 class="mb-0">120</h6>
                    </div>
                </div>
            </div>

            <!-- Total Kelas -->
            <div class="col-sm-6 col-xl-4">
                <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                    <i class="fas fa-dumbbell fa-3x text-primary"></i>
                    <div class="ms-3">
                        <p class="mb-2">Total Kelas</p>
                        <h6 class="mb-0">25</h6>
                    </div>
                </div>
            </div>

            <!-- Total Kegiatan -->
            <div class="col-sm-6 col-xl-4">
                <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                    <i class="fas fa-calendar-check fa-3x text-primary"></i>
                    <div class="ms-3">
                        <p class="mb-2">Total Kegiatan</p>
                        <h6 class="mb-0">15</h6>
                    </div>
                </div>
            </div>
        </div>

        <!-- Jadwal Kelas -->
        <div class="mt-5">
            <h4 class="mb-4">Jadwal Kelas Hari Ini</h4>
            <div class="bg-light rounded p-4">
                <table class="table table-bordered mb-0">
                    <thead>
                        <tr>
                            <th>Jam</th>
                            <th>Nama Kelas</th>
                            <th>Instruktur</th>
                            <th>Ruangan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>08:00 - 09:00</td>
                            <td>Yoga</td>
                            <td>Lisa</td>
                            <td>Ruangan A</td>
                        </tr>
                        <tr>
                            <td>10:00 - 11:00</td>
                            <td>Body Pump</td>
                            <td>John</td>
                            <td>Ruangan B</td>
                        </tr>
                        <tr>
                            <td>16:00 - 17:00</td>
                            <td>Zumba</td>
                            <td>Susan</td>
                            <td>Ruangan C</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Kegiatan Mendatang -->
        <div class="mt-5">
            <h4 class="mb-4">Kegiatan Mendatang</h4>
            <div class="bg-light rounded p-4">
                <ul class="list-group">
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        Kompetisi Push-Up
                        <span class="badge bg-primary rounded-pill">10 Jan</span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        Lomba Angkat Beban
                        <span class="badge bg-primary rounded-pill">20 Jan</span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        Workshop Kesehatan
                        <span class="badge bg-primary rounded-pill">25 Jan</span>
                    </li>
                </ul>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('component.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\rent-car\resources\views/layout/tampilan.blade.php ENDPATH**/ ?>