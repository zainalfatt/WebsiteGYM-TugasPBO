
<?php $__env->startSection('isi'); ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tips Kesehatan untuk Gamer</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
        }
        .hero {
            padding: 50px;
            text-align: center;
            background-color: #343a40;
            color: white;
        }
        .tips-section {
            padding: 20px;
        }
        footer {
            background-color: #343a40;
            color: white;
            padding: 10px 0;
            text-align: center;
        }
    </style>
</head>
<body>
    <!-- Navigasi -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">SehatGamer</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link active" href="#">Beranda</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#tips">Tips</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#kontak">Kontak</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Bagian Hero -->
    <div class="hero">
        <h1>Jaga Kesehatan Saat Bermain Game!</h1>
        <p>Kesehatan Anda sama pentingnya dengan skor permainan. Ikuti tips sederhana ini untuk tetap bugar dan berenergi.</p>
    </div>

    <!-- Bagian Tips Kesehatan -->
    <div class="container tips-section">
        <h2 id="tips" class="mb-4">Tips Kesehatan untuk Gamer</h2>
        <div class="row">
            <div class="col-md-6">
                <h4>1. Istirahat Secara Berkala</h4>
                <p>Berdiri, lakukan peregangan, dan berjalan selama setidaknya 5 menit setiap jam untuk meningkatkan sirkulasi dan mencegah kekakuan.</p>
            </div>
            <div class="col-md-6">
                <h4>2. Tetap Terhidrasi</h4>
                <p>Minum banyak air untuk menjaga tubuh tetap terhidrasi dan pikiran tetap fokus.</p>
            </div>
            <div class="col-md-6">
                <h4>3. Jaga Postur Tubuh</h4>
                <p>Duduk dengan punggung lurus dan layar sejajar dengan mata untuk menghindari sakit punggung dan leher.</p>
            </div>
            <div class="col-md-6">
                <h4>4. Lindungi Mata</h4>
                <p>Gunakan aturan 20-20-20: setiap 20 menit, lihat sesuatu sejauh 20 kaki selama 20 detik untuk mengurangi ketegangan mata.</p>
            </div>
            <div class="col-md-6">
                <h4>5. Olahraga Secara Teratur</h4>
                <p>Masukkan aktivitas fisik ke dalam rutinitas harian Anda untuk meningkatkan energi dan kesehatan secara keseluruhan.</p>
            </div>
            <div class="col-md-6">
                <h4>6. Pilih Camilan Sehat</h4>
                <p>Pilih buah, kacang-kacangan, dan camilan sehat lainnya daripada makanan tidak sehat untuk menjaga nutrisi yang baik.</p>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer>
        <p>&copy; 2025 SehatGamer. Semua Hak Dilindungi.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('component.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\rent-car\resources\views/laporan/laporan.blade.php ENDPATH**/ ?>