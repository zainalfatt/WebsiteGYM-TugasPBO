

<?php $__env->startSection('isi'); ?>
<div class="container">
    <h1>Daftar Membership</h1>
    <a href="<?php echo e(route('membership.create')); ?>" class="btn btn-primary">Tambah Membership</a>
    <table class="table">
        <thead>
            <tr>
                <th>Nama</th>
                <th>Harga</th>
                <th>Durasi</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $memberships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $membership): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($membership->name); ?></td>
                <td>Rp <?php echo e(number_format($membership->price, 2)); ?></td>
                <td><?php echo e($membership->duration); ?></td>
                <td>
                    <a href="<?php echo e(route('membership.edit', $membership)); ?>" class="btn btn-warning">Edit</a>
                    <form action="<?php echo e(route('membership.destroy', $membership)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger" onclick="return confirm('Yakin ingin menghapus?')">Hapus</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('component.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\rent-car\resources\views/membership/membership.blade.php ENDPATH**/ ?>